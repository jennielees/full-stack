jenny = Student()
jenny.name = 'Jenny'
print jenny.name       # prints 'Jenny'
jenny.print_name()     # prints 'Jenny'
