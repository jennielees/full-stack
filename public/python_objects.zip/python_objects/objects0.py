jenny = {}
jenny['name'] = 'Jenny'
print jenny['name']   # prints 'Jenny'
