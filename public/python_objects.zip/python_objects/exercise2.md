Write a class for a school test called Test

 * have a property called score
 * throw an exception if score is less than 0 or greater than 100

Write a class for a student called Student

 * the student should have a name and a list of tests
 * write a method called test_average that returns the student's average grade

Write a class for a group of students called Cohort

 * write a method called print_grades that prints the list of student names and grades:

   Jessie 100
   Cora 78
   Betty 59

----

Write a program that does:

Create a new Cohort
Create 2 students and add them to the cohort
Create 2 tests for each student
Print the list of students
