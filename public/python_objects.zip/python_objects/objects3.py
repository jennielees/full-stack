class Student:
    def print_name(self):
        print self.name

jenny = Student()
jenny.name = 'Jenny'
jenny.print_name()     # prints 'Jenny'
