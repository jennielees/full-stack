Write a Python class that represents a car.
It should have data attributes for make, model,
and year, and a method called `print_details`
that prints the the make, model, and year all on one line, for example:

1985 Ford Taurus
