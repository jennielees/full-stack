 1. `class` keyword
 2. class name
 3. parent class (usually `object`)
 4. docstring
 5. data attributes
 6. methods - the first argument of the method is `self`
 7. creating an instance of the class (an object)
 8. accessing a data attribute on the object
 9. calling a method on the object
